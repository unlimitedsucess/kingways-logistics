// const newConsignment = document.querySelector(".createShipment");
// const createConsignmentBtn = document.getElementById("create-btn");


// // updateStatus.forEach((btn) => {
// //   btn.addEventListener("click", function () {
// //     updateManu.classList.toggle("active2");
// //     console.log("clicked", updateStatus);
// //   });
// // });


// // deleteStatus.forEach ((deletebtn) =>{
// //   deletebtn.addEventListener("click", function(){
// //     deletePackage.classList.toggle("active5")
// //   });
// // });


